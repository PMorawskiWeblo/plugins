<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class WOOMULTI_CURRENCY_Plugin_Wc_Block {
	protected static $settings, $cache=[];
	public function __construct() {
		self::$settings = WOOMULTI_CURRENCY_Data::get_ins();
		if ( !self::$settings->get_enable()) {
			return;
		}
		add_action( 'woocommerce_blocks_checkout_enqueue_data', array( $this, 'wmc_frontend_extra_params' ) );
		add_action( 'woocommerce_blocks_cart_enqueue_data', array( $this, 'wmc_frontend_extra_params' ) );
		add_filter( 'option_woocommerce_currency_pos', [$this,'reset_currency_pos'], 10,1);
	}
	public function reset_currency_pos($value) {
		if (!isset(self::$cache['current_currency_pos'])) {
			$currencies = self::$settings->get_list_currencies();
			$current_currency = self::$settings->get_current_currency();
			$currency = $currencies[$current_currency]??'';
			self::$cache['current_currency_pos'] = $currency['pos'] ??'';
		}
		$value = self::$cache['current_currency_pos'];
		return $value;
	}
	public function wmc_frontend_extra_params() {
		if (wp_script_is('wmc-checkout-block')){
			return;
		}
		$suffix = WP_DEBUG ? '' : '.min';
		wp_enqueue_script( 'wmc-checkout-block', WOOMULTI_CURRENCY_JS . 'frontend-wc-block'.$suffix.'.js', array( 'jquery' ), WOOMULTI_CURRENCY_VERSION, false );
		wp_localize_script( 'wmc-checkout-block', 'wmc_checkout_block_params', apply_filters( 'wmc_checkout_block_params',array(
			'currencies'               => self::$settings->get_list_currencies(),
		) )
		);
	}
}