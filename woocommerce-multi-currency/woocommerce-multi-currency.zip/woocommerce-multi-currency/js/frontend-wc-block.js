(function ($) {
    $(document).ready(function () {
        if (typeof wc !== "undefined" && typeof wc.blocksCheckout !== "undefined"){

            let {registerCheckoutFilters} = wc.blocksCheckout;
            registerCheckoutFilters('wmc_checkout_block_params', {
                // cartItemPrice: formatter,
                // subtotalPriceFormat: formatter,
                // saleBadgePriceFormat: formatter,
                totalValue: formatter,
            });
        }
    });
    function fixShippingOptionPrices(symbol, prefix, suffix) {
        if (!$('.wc-block-formatted-money-amount').length || !$('.wc-block-components-totals-item .wc-block-formatted-money-amount').length){
            setTimeout(function (symbol, prefix, suffix) {
                fixShippingOptionPrices(symbol, prefix, suffix);
            },100,symbol, prefix, suffix);
            return;
        }
        // if ($('.wc-block-components-formatted-money-amount, .wc-block-formatted-money-amount').length){
        $('.wc-block-formatted-money-amount').each(function (k,v) {
            let old_price_html = $(v).text();
            let new_price_html =  normalizeAmountText(old_price_html,symbol, prefix, suffix);
            if (new_price_html != old_price_html) {
                $(v).text(new_price_html);
            }
        })
    }
    function normalizeAmountText(text,symbol, prefix, suffix){
        if (!text) return text;
        if (!symbol) return text;

        let trimmed = text.trim();
        if (trimmed.includes(symbol)) {
            return text;
        }
        return `${prefix}${text}${suffix}`.replace(/\s+/g, ' ');
    }
    function formatter(value, extensions, args){
        if ( args?.cart?.cartTotals?.currency_suffix ||  args?.cart?.cartTotals?.currency_prefix){
            return value;
        }
        let currency_code = args?.cart?.cartTotals?.currency_code,
            currency_symbol = args?.cart?.cartTotals?.currency_symbol;
        if (!currency_code || !currency_symbol || !wmc_checkout_block_params?.currencies
            || !wmc_checkout_block_params.currencies[currency_code]
            || !wmc_checkout_block_params.currencies[currency_code]?.pos){
            return value;
        }
        let prefix='',suffix='';
        switch (wmc_checkout_block_params.currencies[currency_code]?.pos) {
            case 'left':
                prefix = currency_symbol;
                break;
            case 'right':
                suffix = currency_symbol;
                break;
            case 'left_space':
                prefix = `${currency_symbol} `;
                break;
            case 'right_space':
                suffix = ` ${currency_symbol}`;
                break;
        }
        fixShippingOptionPrices(currency_symbol, prefix, suffix);
        return value;
        // if (/<price\/>/.test(String(value))) {
        //     return `${prefix}<price/>${suffix}`;
        // }
        // return `${prefix}${value}${suffix}`;
    }
}(jQuery));